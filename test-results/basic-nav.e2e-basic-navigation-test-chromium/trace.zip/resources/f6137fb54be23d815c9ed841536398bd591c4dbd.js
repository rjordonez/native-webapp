(function() {
  window._POSTHOG_REMOTE_CONFIG = window._POSTHOG_REMOTE_CONFIG || {};
  window._POSTHOG_REMOTE_CONFIG['phc_r8qJSp8nLcckoqtVwN9y1mE4JuY3xZU9d30JSqlVAHq'] = {
    config: {"token": "phc_r8qJSp8nLcckoqtVwN9y1mE4JuY3xZU9d30JSqlVAHq", "supportedCompression": ["gzip", "gzip-js"], "hasFeatureFlags": false, "captureDeadClicks": false, "capturePerformance": {"network_timing": true, "web_vitals": true, "web_vitals_allowed_metrics": null}, "autocapture_opt_out": false, "autocaptureExceptions": false, "analytics": {"endpoint": "/i/v0/e/"}, "elementsChainAsString": true, "sessionRecording": false, "heatmaps": true, "surveys": false, "defaultIdentifiedOnly": true},
    siteApps: []
  }
})();